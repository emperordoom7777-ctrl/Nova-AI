# Nova — Original AI Chat Application

A small, modular ChatGPT-style web application. This is original example code; it is not OpenAI's private ChatGPT source code and does not contain or train a foundation model.

## Requirements
- Node.js 18 or newer
- An API key from an AI provider that supports the Chat Completions-compatible API used in `server/services/ai-provider.js`

## Run locally
1. Extract this folder.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your provider API key in `AI_API_KEY` and choose a model in `AI_MODEL`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

If no API key is configured, the interface still runs and explains that the provider needs configuration.

## Modules
- `public/index.html`: semantic page structure and interface regions.
- `public/styles.css`: responsive dark theme and layout.
- `public/app.js`: chat state, local conversation history, rendering and API requests.
- `server/index.js`: Express server, static hosting, request validation and rate limiting.
- `server/services/ai-provider.js`: server-side AI provider adapter. API credentials never enter browser code.

## Important limitations
- This starter stores chat history in the browser's local storage. It is not synced between devices and is not suitable for shared/public multi-user production.
- Add a database, proper authentication, account-level authorization, logging controls, abuse prevention, and deployment secrets before launching to customers.
- The sample uses a non-streaming response. Streaming, file upload, image generation, web search, and admin controls are not implemented yet.
- Never commit `.env` or expose API keys in frontend files.
