const conversationEl = document.querySelector("#conversation");
const messagesEl = document.querySelector("#messages");
const welcomeEl = document.querySelector("#welcome");
const form = document.querySelector("#chatForm");
const input = document.querySelector("#messageInput");
const sendButton = document.querySelector("#sendButton");
const historyList = document.querySelector("#historyList");
const sidebar = document.querySelector("#sidebar");

let chats = loadChats();
let activeChatId = chats[0]?.id || null;
let busy = false;

function makeId() {
  return globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function loadChats() {
  try {
    const saved = JSON.parse(localStorage.getItem("nova-chats") || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch { return []; }
}
function saveChats() {
  // Local demo history only. Use a database and user accounts for production.
  localStorage.setItem("nova-chats", JSON.stringify(chats));
}
function activeChat() {
  return chats.find(chat => chat.id === activeChatId);
}
function createChat() {
  const chat = { id: makeId(), title: "New chat", messages: [], updatedAt: Date.now() };
  chats.unshift(chat);
  activeChatId = chat.id;
  saveChats();
  render();
  input.focus();
}
function escapeText(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}
function renderHistory() {
  historyList.innerHTML = "";
  for (const chat of chats) {
    const button = document.createElement("button");
    button.className = `history-item${chat.id === activeChatId ? " active" : ""}`;
    button.textContent = chat.title;
    button.title = chat.title;
    button.addEventListener("click", () => {
      activeChatId = chat.id;
      sidebar.classList.remove("open");
      render();
    });
    historyList.append(button);
  }
}
function renderMessages() {
  const chat = activeChat();
  const messages = chat?.messages || [];
  welcomeEl.hidden = messages.length > 0;
  messagesEl.innerHTML = "";
  for (const message of messages) {
    const row = document.createElement("article");
    row.className = `message ${message.role}`;
    if (message.role === "assistant") {
      const avatar = document.createElement("div");
      avatar.className = "message-avatar";
      avatar.textContent = "N";
      row.append(avatar);
    }
    const content = document.createElement("div");
    content.className = "message-content";
    content.textContent = message.content;
    row.append(content);
    messagesEl.append(row);
  }
  conversationEl.scrollTop = conversationEl.scrollHeight;
}
function render() {
  renderHistory();
  renderMessages();
}
function setBusy(value) {
  busy = value;
  sendButton.disabled = value;
  input.disabled = value;
  sendButton.textContent = value ? "…" : "↑";
}
async function sendMessage(text) {
  if (busy || !text.trim()) return;
  if (!activeChatId) createChat();
  const chat = activeChat();
  chat.messages.push({ role: "user", content: text.trim() });
  if (chat.messages.length === 1) chat.title = text.trim().slice(0, 34) || "New chat";
  chat.updatedAt = Date.now();
  saveChats();
  input.value = "";
  resizeInput();
  render();
  setBusy(true);

  const pending = document.createElement("article");
  pending.className = "message assistant";
  pending.innerHTML = '<div class="message-avatar">N</div><div class="message-content typing">Thinking…</div>';
  messagesEl.append(pending);
  conversationEl.scrollTop = conversationEl.scrollHeight;

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: chat.messages.slice(-40) })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed");
    chat.messages.push({ role: "assistant", content: data.reply });
    chat.updatedAt = Date.now();
    saveChats();
  } catch (error) {
    chat.messages.push({ role: "assistant", content: `Sorry, something went wrong: ${error.message}` });
    saveChats();
  } finally {
    setBusy(false);
    render();
    input.focus();
  }
}
function resizeInput() {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendMessage(input.value);
});
input.addEventListener("input", resizeInput);
input.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});
document.querySelector("#newChat").addEventListener("click", createChat);
document.querySelector("#clearChat").addEventListener("click", () => {
  const chat = activeChat();
  if (!chat || !chat.messages.length || !confirm("Clear this conversation?")) return;
  chat.messages = [];
  chat.title = "New chat";
  saveChats();
  render();
});
document.querySelector("#openSidebar").addEventListener("click", () => sidebar.classList.add("open"));
document.querySelector("#closeSidebar").addEventListener("click", () => sidebar.classList.remove("open"));
document.querySelectorAll(".suggestion").forEach(button => {
  button.addEventListener("click", () => {
    input.value = button.dataset.prompt || "";
    resizeInput();
    input.focus();
  });
});

if (!activeChatId) createChat();
else render();
