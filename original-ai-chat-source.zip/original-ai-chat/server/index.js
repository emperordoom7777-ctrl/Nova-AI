import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createChatReply } from "./services/ai-provider.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 30 }));
app.use(express.static(path.join(__dirname, "../public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, providerConfigured: Boolean(process.env.AI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 40) {
      return res.status(400).json({ error: "Send between 1 and 40 messages." });
    }

    const safeMessages = [];
    for (const message of messages) {
      if (!message || !["user", "assistant"].includes(message.role) ||
          typeof message.content !== "string" || message.content.length > 12_000) {
        return res.status(400).json({ error: "A message is invalid or too long." });
      }
      safeMessages.push({ role: message.role, content: message.content });
    }

    const reply = await createChatReply(safeMessages);
    res.json({ reply });
  } catch (error) {
    console.error("Chat request failed:", error.message);
    res.status(500).json({ error: error.message || "The AI service could not respond." });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

app.listen(PORT, () => {
  console.log(`AI Chat is running at http://localhost:${PORT}`);
});
