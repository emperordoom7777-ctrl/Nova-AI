const SYSTEM_INSTRUCTIONS = `You are a helpful AI assistant in an original chat application.
Be accurate, clear, and honest. If you are uncertain, say so.
Do not claim to have performed actions you did not perform.`;

export async function createChatReply(messages) {
  const apiKey = process.env.AI_API_KEY;
  if (!apiKey) {
    return "The interface is running, but no AI provider is configured yet. Add your API key to the .env file on the server, then restart the app.";
  }

  const baseUrl = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const model = process.env.AI_MODEL || "gpt-4.1-mini";

  // Uses the widely supported Chat Completions-compatible endpoint.
  // The key stays on the server and is never sent to the browser.
  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      messages: [{ role: "system", content: SYSTEM_INSTRUCTIONS }, ...messages],
      temperature: 0.7
    })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = data?.error?.message || `AI provider returned HTTP ${response.status}`;
    throw new Error(detail);
  }

  const text = data?.choices?.[0]?.message?.content;
  if (typeof text !== "string" || !text.trim()) {
    throw new Error("The AI provider returned an empty response.");
  }
  return text.trim();
}
